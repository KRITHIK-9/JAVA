package com.music.player;

public interface Musicplayer {
	void play();

}
