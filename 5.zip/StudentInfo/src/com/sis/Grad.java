package com.sis;

public class Grad extends Student{
	public Grad(String id, String name) {
        super(id, name);
    }

}
