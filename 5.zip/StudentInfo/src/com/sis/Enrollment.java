package com.sis;

public interface Enrollment {
	  void enroll(Student student, Course course);
}
