package com.sis;

public class Undergrad extends Student{
	 public Undergrad(String id, String name) {
	        super(id, name);
	    }

}
